<?php

echo "21545";

?>

<script>
var res=document.getElementsByTagName('html').innerHTML;
alert(res);
</script>