<?php
$color="2,3,15,12,13:1";
$array=array();
$array=(explode(',',$color));
print_r($array);
	
?>